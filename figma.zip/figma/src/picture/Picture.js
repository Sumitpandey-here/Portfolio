import React from 'react'

const Picture = () => {
  return (
    <div className='picture_style'>
      <img src={require('../picture/pexels-wictor-cardoso-18269632-removebg 1.png')} alt="React Image" />

    </div>
  )
}

export default Picture
