import React from 'react'



const Button = (props) => {
  return (
    <div className='button'>
      {
        props.buttonname
      }
    </div>
  )
}

export default Button




