import React from 'react'

const Percentage = (props) => {
  return (
    <div>
      <h5>
{
    props.abc
}
      </h5>
      <div className='percent'>

      </div>
    </div>
  )
}

export default Percentage
