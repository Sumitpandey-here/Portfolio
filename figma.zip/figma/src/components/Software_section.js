import React from 'react'

const Software_section = () => {
  return (
    <div className='software'>
     <img src={require('../picture/logo-1.png')} alt="React Image" />
     <img src={require('../picture/logo-2.png')} alt="React Image" />
     <img src={require('../picture/logo-3.png')} alt="React Image" />
     {/* <img src={require('../picture/logo-4.png')} alt="React Image" /> */}
     <img src={require('../picture/logo-5.png')} alt="React Image" />
     <img src={require('../picture/logo-6.png')} alt="React Image" />

    </div>
  )
}

export default Software_section
