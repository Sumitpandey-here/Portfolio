import React from 'react'
import New_card from './New_card'

const Achieve = () => {
  return (
    <div>
<div className='achieve'>
<div>
    <h6 className='achive_div1'>
    Our Milestones
    </h6>

    <h2 className='achive_div2'>
    What sets our studio apart for your projects?
    </h2>
</div>
<div className='last_div'>
<New_card tttl1="8300+" tttl2="Figma ipsum component variant main layer. Hand."/>
<New_card tttl1="100%" tttl2="Figma ipsum component variant main layer. Union."/>
<New_card tttl1="3.5K" tttl2="Figma ipsum component variant main layer. Hand."/>
<New_card tttl1="240+" tttl2="Figma ipsum component variant main layer. Hand."/>
</div>

</div>
    </div>
  )
}

export default Achieve
