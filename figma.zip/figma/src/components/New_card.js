import React from 'react'

const New_card = (props) => {
    return (
        
            <div className='new_card'>

                <h2 className='ttl1'>{props.tttl1}</h2>
                <h6 className='ttl2'>{props.tttl2
                }</h6>

            </div>
        
    )
}

export default New_card
