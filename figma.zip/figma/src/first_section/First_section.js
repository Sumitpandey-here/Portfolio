import React from 'react'

const First_section = () => {
  return (
    <>
    <div className='full_section'>
    <div className='first_section'>
      <h6 style={{color: "red"}}>Welcome to My Portfolio</h6>
      <h2>Hello , I am Sumit Pandey</h2> 
      <h2>Web developer</h2>
      <h4>Collaborating with highly skilled individuals, our agency delivers top-quality services.</h4>
    </div>
    <div className='set_button'>
     <button className='button_hire'>Hire me </button>  
     <button className='download'>Download CV </button> 
     </div> 
     </div>
     </> 
  )
}

export default First_section
